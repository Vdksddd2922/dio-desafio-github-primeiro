
class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    background: linear-gradient(135deg, #0a0a14 0%, #161627 100%);
                    color: white;
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    position: relative;
                    overflow: hidden;
                }

                :host::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: radial-gradient(circle at 20% 30%, rgba(74, 20, 140, 0.1) 0%, transparent 40%),
                                radial-gradient(circle at 80% 70%, rgba(30, 136, 229, 0.1) 0%, transparent 40%);
                    z-index: 0;
                }
                .footer-container {
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 5rem 2rem 3rem;
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 4rem;
                    position: relative;
                    z-index: 1;
                }
.footer-section {
                    margin-bottom: 2rem;
                }
                
                .footer-logo {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    margin-bottom: 1.5rem;
                }
                
                .logo-text {
                    font-size: 1.5rem;
                    font-weight: 700;
                    background: linear-gradient(to right, #fff, #aaa);
                    -webkit-background-clip: text;
                    background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                
                .footer-about {
                    color: rgba(255, 255, 255, 0.7);
                    line-height: 1.7;
                    margin-bottom: 1.5rem;
                }
                
                .footer-social {
                    display: flex;
                    gap: 1rem;
                }
                .social-link {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 42px;
                    height: 42px;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.08);
                    color: white;
                    transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                    position: relative;
                    overflow: hidden;
                }

                .social-link::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(135deg, #4a148c, #1e88e5);
                    z-index: -1;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }

                .social-link:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 5px 15px rgba(74, 20, 140, 0.3);
                }

                .social-link:hover::before {
                    opacity: 1;
                }
.social-link:hover {
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                    transform: translateY(-3px);
                }
                
                .footer-title {
                    font-size: 1.25rem;
                    font-weight: 600;
                    margin-bottom: 1.5rem;
                    color: white;
                    position: relative;
                    padding-bottom: 0.5rem;
                }
                
                .footer-title::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 40px;
                    height: 2px;
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                }
                
                .footer-links {
                    display: flex;
                    flex-direction: column;
                    gap: 0.75rem;
                }
                .footer-link {
                    color: rgba(255, 255, 255, 0.7);
                    text-decoration: none;
                    transition: all 0.3s ease;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    position: relative;
                    width: fit-content;
                }

                .footer-link::before {
                    content: '';
                    position: absolute;
                    bottom: -2px;
                    left: 0;
                    width: 0;
                    height: 1px;
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                    transition: width 0.3s ease;
                }

                .footer-link:hover::before {
                    width: 100%;
                }
.footer-link:hover {
                    color: #1e88e5;
                    transform: translateX(5px);
                }
                
                .footer-contact-item {
                    display: flex;
                    gap: 1rem;
                    margin-bottom: 1rem;
                    align-items: flex-start;
                }
                
                .footer-contact-icon {
                    color: #1e88e5;
                    margin-top: 3px;
                }
                
                .footer-contact-text {
                    color: rgba(255, 255, 255, 0.7);
                }
                .footer-bottom {
                    background: rgba(0, 0, 0, 0.3);
                    padding: 1.5rem;
                    text-align: center;
                    color: rgba(255, 255, 255, 0.7);
                    font-size: 0.9rem;
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    position: relative;
                    z-index: 1;
                    backdrop-filter: blur(5px);
                }

                .footer-bottom::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(90deg, transparent, rgba(74, 20, 140, 0.2), transparent);
                    z-index: -1;
                }
.newsletter-form {
                    display: flex;
                    gap: 0.5rem;
                    margin-top: 1rem;
                }
                
                .newsletter-input {
                    flex: 1;
                    padding: 0.75rem;
                    border-radius: 4px;
                    border: none;
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                }
                
                .newsletter-button {
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                    color: white;
                    border: none;
                    padding: 0 1.5rem;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .newsletter-button:hover {
                    opacity: 0.9;
                }
                
                @media (max-width: 768px) {
                    .footer-container {
                        grid-template-columns: 1fr;
                    }
                    
                    .newsletter-form {
                        flex-direction: column;
                    }
                }
            </style>
            
            <div class="footer-container">
                <div class="footer-section">
                    <div class="footer-logo">
                        <i data-feather="scale" class="logo-icon"></i>
                        <span class="logo-text">Dark Justice</span>
                    </div>
                    <p class="footer-about">
                        Especialistas em soluções jurídicas inovadoras e personalizadas para proteger seus direitos e interesses.
                    </p>
                    <div class="footer-social">
                        <a href="#" class="social-link" aria-label="Facebook">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Instagram">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="LinkedIn">
                            <i data-feather="linkedin"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Twitter">
                            <i data-feather="twitter"></i>
                        </a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3 class="footer-title">Links Úteis</h3>
                    <div class="footer-links">
                        <a href="#sobre" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Sobre Nós
                        </a>
                        <a href="#servicos" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Serviços
                        </a>
                        <a href="#equipe" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Nossa Equipe
                        </a>
                        <a href="#contato" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Contato
                        </a>
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Blog Jurídico
                        </a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3 class="footer-title">Áreas de Atuação</h3>
                    <div class="footer-links">
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Direito Civil
                        </a>
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Direito Empresarial
                        </a>
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Direito Digital
                        </a>
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Direito Tributário
                        </a>
                        <a href="#" class="footer-link">
                            <i data-feather="chevron-right"></i>
                            Direito de Família
                        </a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3 class="footer-title">Contato</h3>
                    <div class="footer-contact">
                        <div class="footer-contact-item">
                            <i data-feather="map-pin" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">Av. Paulista, 1000 - São Paulo/SP</span>
                        </div>
                        <div class="footer-contact-item">
                            <i data-feather="mail" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">contato@darkjustice.com.br</span>
                        </div>
                        <div class="footer-contact-item">
                            <i data-feather="phone" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">(11) 9999-9999</span>
                        </div>
                        <div class="footer-contact-item">
                            <i data-feather="clock" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">Seg-Sex: 9h às 18h</span>
                        </div>
                    </div>
                    
                    <h3 class="footer-title" style="margin-top: 2rem;">Newsletter</h3>
                    <form class="newsletter-form">
                        <input type="email" class="newsletter-input" placeholder="Seu e-mail" required>
                        <button type="submit" class="newsletter-button">
                            <i data-feather="send"></i>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="flex items-center justify-center gap-1">
                    <i data-feather="copyright"></i>
                    <span>${new Date().getFullYear()} Dark Justice Advocates. Todos os direitos reservados.</span>
                </div>
            </div>
`;
        
        // Replace feather icons
        const featherScript = document.createElement('script');
        featherScript.textContent = 'feather.replace();';
        this.shadowRoot.appendChild(featherScript);
    }
}

customElements.define('custom-footer', CustomFooter);