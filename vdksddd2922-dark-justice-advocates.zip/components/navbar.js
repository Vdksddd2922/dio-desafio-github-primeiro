
class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    z-index: 1000;
                    transition: all 0.3s ease;
                    background: rgba(26, 26, 46, 0.9);
                    backdrop-filter: blur(10px);
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                .navbar-container {
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 1rem 2rem;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .logo {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    text-decoration: none;
                }
                
                .logo-icon {
                    color: #1e88e5;
                    width: 32px;
                    height: 32px;
                }
                
                .logo-text {
                    font-size: 1.5rem;
                    font-weight: 700;
                    background: linear-gradient(to right, #fff, #aaa);
                    -webkit-background-clip: text;
                    background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .nav-links {
                    display: flex;
                    gap: 2rem;
                    align-items: center;
                    transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                }
.nav-link {
                    color: rgba(255, 255, 255, 0.8);
                    text-decoration: none;
                    font-weight: 500;
                    transition: all 0.3s ease;
                    position: relative;
                    padding: 0.5rem 0;
                }
                
                .nav-link:hover {
                    color: white;
                }
                
                .nav-link::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 0;
                    height: 2px;
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                    transition: width 0.3s ease;
                }
                
                .nav-link:hover::after {
                    width: 100%;
                }
                
                .cta-button {
                    background: linear-gradient(to right, #4a148c, #1e88e5);
                    color: white;
                    font-weight: 600;
                    padding: 0.75rem 1.5rem;
                    border-radius: 50px;
                    transition: all 0.3s ease;
                    text-decoration: none;
                    display: inline-block;
                }
                
                .cta-button:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
                }
                .mobile-menu-btn {
                    display: none;
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    padding: 0.5rem;
                    transition: transform 0.3s ease;
                }

                .mobile-menu-btn:hover {
                    transform: rotate(90deg);
                }

                .nav-link.active {
                    color: white;
                    font-weight: 600;
                }

                .nav-link.active::after {
                    width: 100%;
                }
@media (max-width: 768px) {
                    .nav-links {
                        position: fixed;
                        top: 80px;
                        left: 0;
                        right: 0;
                        background: rgba(13, 13, 26, 0.98);
                        flex-direction: column;
                        align-items: center;
                        padding: 2rem 0;
                        gap: 1.5rem;
                        transform: translateY(-100vh);
                        transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                        z-index: 999;
                        backdrop-filter: blur(15px);
                        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                    }
.nav-links.active {
                        transform: translateY(0);
                    }
                    
                    .mobile-menu-btn {
                        display: block;
                    }
                }
            </style>
            
            <div class="navbar-container">
                <a href="/" class="logo">
                    <i data-feather="scale" class="logo-icon"></i>
                    <span class="logo-text">Dark Justice</span>
                </a>
                
                <div class="nav-links">
                    <a href="#sobre" class="nav-link">Sobre</a>
                    <a href="#servicos" class="nav-link">Serviços</a>
                    <a href="#equipe" class="nav-link">Equipe</a>
                    <a href="#contato" class="nav-link">Contato</a>
                    <a href="#whatsapp" class="cta-button">Agendar Consulta</a>
                </div>
                
                <button class="mobile-menu-btn" aria-label="Menu">
                    <i data-feather="menu"></i>
                </button>
            </div>
`;
        
        // Mobile menu toggle
        const mobileMenuBtn = this.shadowRoot.querySelector('.mobile-menu-btn');
        const navLinks = this.shadowRoot.querySelector('.nav-links');
        
        if(mobileMenuBtn && navLinks) {
            mobileMenuBtn.addEventListener('click', () => {
                navLinks.classList.toggle('active');
                const icon = mobileMenuBtn.querySelector('i');
                if(navLinks.classList.contains('active')) {
                    icon.setAttribute('data-feather', 'x');
                } else {
                    icon.setAttribute('data-feather', 'menu');
                }
                feather.replace();
            });
        }
    }
}

customElements.define('custom-navbar', CustomNavbar);