class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    background-color: #0d0d1a;
                    color: white;
                }
                
                .footer-container {
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 4rem 2rem;
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 3rem;
                }
                
                .footer-logo {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    font-size: 1.5rem;
                    font-weight: 700;
                    margin-bottom: 1.5rem;
                }
                
                .footer-logo-icon {
                    color: #1e88e5;
                }
                
                .footer-about {
                    margin-bottom: 1.5rem;
                    color: rgba(255, 255, 255, 0.7);
                    line-height: 1.6;
                }
                
                .footer-social {
                    display: flex;
                    gap: 1rem;
                }
                
                .social-link {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    background-color: rgba(255, 255, 255, 0.1);
                    color: white;
                    transition: all 0.3s ease;
                }
                
                .social-link:hover {
                    background-color: #1e88e5;
                    transform: translateY(-3px);
                }
                
                .footer-title {
                    font-size: 1.25rem;
                    font-weight: 600;
                    margin-bottom: 1.5rem;
                    position: relative;
                    padding-bottom: 0.75rem;
                }
                
                .footer-title::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 50px;
                    height: 2px;
                    background-color: #1e88e5;
                }
                
                .footer-links {
                    display: flex;
                    flex-direction: column;
                    gap: 0.75rem;
                }
                
                .footer-link {
                    color: rgba(255, 255, 255, 0.7);
                    text-decoration: none;
                    transition: all 0.3s ease;
                }
                
                .footer-link:hover {
                    color: #1e88e5;
                    padding-left: 5px;
                }
                
                .footer-contact-item {
                    display: flex;
                    gap: 1rem;
                    margin-bottom: 1rem;
                    align-items: flex-start;
                }
                
                .footer-contact-icon {
                    color: #1e88e5;
                    margin-top: 3px;
                }
                
                .footer-contact-text {
                    color: rgba(255, 255, 255, 0.7);
                }
                
                .footer-bottom {
                    background-color: #0a0a12;
                    padding: 1.5rem 2rem;
                    text-align: center;
                    color: rgba(255, 255, 255, 0.5);
                    font-size: 0.875rem;
                }
                
                @media (max-width: 768px) {
                    .footer-container {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
            
            <div class="footer-container">
                <div>
                    <div class="footer-logo">
                        <i data-feather="scale" class="footer-logo-icon"></i>
                        <span>Dark Justice</span>
                    </div>
                    <p class="footer-about">
                        Somos um escritório de advocacia comprometido com a excelência jurídica e a satisfação de nossos clientes, oferecendo soluções personalizadas para cada caso.
                    </p>
                    <div class="footer-social">
                        <a href="#" class="social-link">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i data-feather="linkedin"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i data-feather="twitter"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h3 class="footer-title">Links Rápidos</h3>
                    <div class="footer-links">
                        <a href="#sobre" class="footer-link">Sobre Nós</a>
                        <a href="#servicos" class="footer-link">Nossos Serviços</a>
                        <a href="#contato" class="footer-link">Entre em Contato</a>
                        <a href="#" class="footer-link">Termos de Serviço</a>
                        <a href="#" class="footer-link">Política de Privacidade</a>
                    </div>
                </div>
                
                <div>
                    <h3 class="footer-title">Áreas de Atuação</h3>
                    <div class="footer-links">
                        <a href="#" class="footer-link">Direito Empresarial</a>
                        <a href="#" class="footer-link">Direito Imobiliário</a>
                        <a href="#" class="footer-link">Direito de Família</a>
                        <a href="#" class="footer-link">Direito Criminal</a>
                        <a href="#" class="footer-link">Direito Digital</a>
                    </div>
                </div>
                
                <div>
                    <h3 class="footer-title">Contato</h3>
                    <div class="footer-contact">
                        <div class="footer-contact-item">
                            <i data-feather="map-pin" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">Av. Paulista, 1000 - 10º andar, São Paulo/SP</span>
                        </div>
                        <div class="footer-contact-item">
                            <i data-feather="mail" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">contato@darkjustice.com.br</span>
                        </div>
                        <div class="footer-contact-item">
                            <i data-feather="phone" class="footer-contact-icon"></i>
                            <span class="footer-contact-text">(11) 9999-9999</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                &copy; ${new Date().getFullYear()} Dark Justice Advocates. Todos os direitos reservados.
            </div>
        `;
        
        // Replace feather icons
        const featherScript = document.createElement('script');
        featherScript.textContent = 'feather.replace();';
        this.shadowRoot.appendChild(featherScript);
    }
}

customElements.define('custom-footer', CustomFooter);