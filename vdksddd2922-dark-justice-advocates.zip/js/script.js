document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if(targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if(targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
    // Close mobile menu when clicking a link
    document.addEventListener('click', function(e) {
        const navbar = document.querySelector('custom-navbar');
        if(navbar && window.innerWidth <= 768) {
            if(e.target.closest('.nav-link')) {
                const navLinks = navbar.shadowRoot.querySelector('.nav-links');
                const menuBtn = navbar.shadowRoot.querySelector('.mobile-menu-btn');
                if(navLinks && menuBtn) {
                    navLinks.classList.remove('active');
                    menuBtn.querySelector('i').setAttribute('data-feather', 'menu');
                    feather.replace();
                }
            }
        }
    });
});
}
        });
    });
    
    // Form submission handling
    const contactForm = document.querySelector('form');
    if(contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simple validation
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;
            
            if(!name || !email || !message) {
                alert('Por favor, preencha todos os campos obrigatórios.');
                return;
            }
            
            // Here you would typically send the form data to a server
            alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
            contactForm.reset();
        });
    }
    // Sticky navbar on scroll
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('custom-navbar');
        if(navbar) {
            if(window.scrollY > 100) {
                navbar.classList.add('bg-primary');
                navbar.classList.add('shadow-lg');
            } else {
                navbar.classList.remove('bg-primary');
                navbar.classList.remove('shadow-lg');
            }
        }

        // Highlight active nav link
        document.querySelectorAll('section').forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if(window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                document.querySelectorAll(`custom-navbar .nav-link`).forEach(link => {
                    link.classList.remove('active');
                    if(link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    });
});